package taojinke.qianxing.earlywarning.ui;

import javax.inject.Inject;


/**
 * ***********************************************
 * 包路径：taojinke.qianxing.earlywarning.ui
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/2/28+19:20
 * 修改人：
 * 修改时间：2019/2/28+19:20
 * 修改备注：
 * ***********************************************
 */
public class TaskEcecuterPresenter implements TaskEcecuterContract.ITaskEcecuterPresenter {
    @Inject
    TaskEcecuterContract.ITaskEcecuterView mView;
}
