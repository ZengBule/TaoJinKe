package taojinke.qianxing.earlywarning.ui;


public class HaveWaitingCompletData {
    private String haveData;

    public String getHaveData() {
        return haveData;
    }

    public void setHaveData(String haveData) {
        this.haveData = haveData;
    }
}
