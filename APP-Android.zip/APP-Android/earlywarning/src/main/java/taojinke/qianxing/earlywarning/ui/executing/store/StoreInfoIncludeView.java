package taojinke.qianxing.earlywarning.ui.executing.store;


import taojinke.qianxing.lib_weight.countdownview.CountdownView;

public class StoreInfoIncludeView {


    private StoreInfo storeInfo;
    private CountdownView countdownView;

    public StoreInfo getStoreInfo() {
        return storeInfo;
    }

    public void setStoreInfo(StoreInfo storeInfo) {
        this.storeInfo = storeInfo;
    }

    public CountdownView getCountdownView() {
        return countdownView;
    }

    public void setCountdownView(CountdownView countdownView) {
        this.countdownView = countdownView;
    }

}