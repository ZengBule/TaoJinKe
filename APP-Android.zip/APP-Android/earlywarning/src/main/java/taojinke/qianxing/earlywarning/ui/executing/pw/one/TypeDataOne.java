package taojinke.qianxing.earlywarning.ui.executing.pw.one;


/**
 *
 */
public class TypeDataOne {
    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }

    private int value;

}