package taojinke.qianxing.earlywarning.ui.executing.store;

public class AlarmInfo {

    private boolean isPutOn;

    public boolean isPutOn() {
        return isPutOn;
    }

    public void setPutOn(boolean putOn) {
        isPutOn = putOn;
    }
}