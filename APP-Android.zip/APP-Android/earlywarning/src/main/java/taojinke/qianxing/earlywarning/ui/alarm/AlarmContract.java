package taojinke.qianxing.earlywarning.ui.alarm;

import taojinke.qianxing.lib_base.base.BaseView;


/**
 * ***********************************************
 * 包路径：taojinke.qianxing.earlywarning.ui.alarm
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/3/1+10:36
 * 修改人：
 * 修改时间：2019/3/1+10:36
 * 修改备注：
 * ***********************************************
 */
public interface AlarmContract {
    interface IAlarmView extends BaseView {

    }

    interface IAlarmPresenter {

    }
}
