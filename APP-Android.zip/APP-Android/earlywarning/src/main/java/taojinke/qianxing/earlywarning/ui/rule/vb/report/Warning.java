package taojinke.qianxing.earlywarning.ui.rule.vb.report;

/**
 * ***********************************************
 * 包路径：qianxing.taojinke.ui.taskstatus.alarmRuler.vb.report
 * 类描述：
 * 创建人：曾小浪[PHONE：18613223863]
 * 创建时间：2018/12/21+9:44
 * 修改人：
 * 修改时间：2018/12/21+9:44
 * 修改备注：
 * ***********************************************
 */
public class Warning {

}