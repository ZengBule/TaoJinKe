package taojinke.qianxing.earlywarning.ui.clazz;

import javax.inject.Inject;


/**
 * ***********************************************
 * 包路径：taojinke.qianxing.earlywarning.ui.clazz
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/3/1+10:05
 * 修改人：
 * 修改时间：2019/3/1+10:05
 * 修改备注：
 * ***********************************************
 */
public class TaskWaitCompletPresenter implements TaskWaitCompletContract.ITaskWaitCompletPresenter {
    @Inject
    TaskWaitCompletContract.ITaskWaitCompletView mView;
}
