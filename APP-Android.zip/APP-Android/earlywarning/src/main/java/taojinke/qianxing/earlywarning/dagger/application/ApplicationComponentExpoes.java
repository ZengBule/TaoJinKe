package taojinke.qianxing.earlywarning.dagger.application;


import taojinke.qianxing.earlywarning.dagger.application.module.ApplicationLikeModule;

public interface ApplicationComponentExpoes extends ApplicationLikeModule.Exposes {
}
