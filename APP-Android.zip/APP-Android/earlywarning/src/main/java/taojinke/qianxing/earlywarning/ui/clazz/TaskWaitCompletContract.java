package taojinke.qianxing.earlywarning.ui.clazz;

import me.drakeet.multitype.MultiTypeAdapter;
import taojinke.qianxing.lib_base.base.BaseView;


/**
 * ***********************************************
 * 包路径：taojinke.qianxing.earlywarning.ui.clazz
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/3/1+10:05
 * 修改人：
 * 修改时间：2019/3/1+10:05
 * 修改备注：
 * ***********************************************
 */
public interface TaskWaitCompletContract {
    interface ITaskWaitCompletView extends BaseView {
    }

    interface ITaskWaitCompletPresenter {
    }
}
