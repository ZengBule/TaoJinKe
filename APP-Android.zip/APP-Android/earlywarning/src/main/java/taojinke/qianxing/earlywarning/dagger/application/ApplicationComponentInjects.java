package taojinke.qianxing.earlywarning.dagger.application;


import taojinke.qianxing.earlywarning.app.TaskApplicationLikeImpl;

/**
 * ***********************************************
 * 包路径：
 * 类描述：
 * 创建人：Zengxialang[PHONE：18613223863]
 * 创建时间：2018/9/17
 * 修改人：
 * 修改时间：2018/9/17
 * 修改备注：
 * ***********************************************
 */

public interface ApplicationComponentInjects {
    void inject(TaskApplicationLikeImpl application);

}
