package taojinke.qianxing.earlywarning.ui.executing.pw.three;

/**
 * 预警未处理
 */
public class RediuceAlarm {

    private int vlaue;

    public int getVlaue() {
        return vlaue;
    }

    public void setVlaue(int vlaue) {
        this.vlaue = vlaue;
    }
}