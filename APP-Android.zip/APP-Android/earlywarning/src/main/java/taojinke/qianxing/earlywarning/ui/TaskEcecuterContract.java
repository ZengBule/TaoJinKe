package taojinke.qianxing.earlywarning.ui;

import taojinke.qianxing.lib_base.base.BaseView;


/**
 * ***********************************************
 * 包路径：taojinke.qianxing.earlywarning.ui
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/2/28+19:20
 * 修改人：
 * 修改时间：2019/2/28+19:20
 * 修改备注：
 * ***********************************************
 */
public interface TaskEcecuterContract {
    interface ITaskEcecuterView extends BaseView {

    }

    interface ITaskEcecuterPresenter {

    }
}
