package taojinke.qianxing.train.dagger.application;

import taojinke.qianxing.train.app.TrainApplicationLike;

public interface TrainApplicationComponentInjects {

    void inject(TrainApplicationLike trainApplicationLike);
}
