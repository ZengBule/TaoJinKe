package taojinke.qianxing.train.dagger.fragments;

public interface FragmentComponentInjects {
}
