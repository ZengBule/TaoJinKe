package taojinke.qianxing.lib_weight.loading.callback;

import android.view.View;

import androidx.annotation.NonNull;

/**
 * 重试
 * Created by dgg on 2017/11/7.
 */

public interface OnRetryClickListener {
    void onRetry(@NonNull View view);
}
