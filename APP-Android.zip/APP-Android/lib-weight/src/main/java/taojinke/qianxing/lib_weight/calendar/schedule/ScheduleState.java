package taojinke.qianxing.lib_weight.calendar.schedule;

/**
 * Created by Jimmy on 2016/10/8 0008.
 */
public enum ScheduleState {
    OPEN,
    CLOSE
}
