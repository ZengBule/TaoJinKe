package taojinke.qianxing.lib_kernel.http.app;


/**
 * @author Administrator
 */
public enum ConfigKeys {
    API_HOST,
    APPLICATION_CONTEXT,
    CONFIG_READY
}
