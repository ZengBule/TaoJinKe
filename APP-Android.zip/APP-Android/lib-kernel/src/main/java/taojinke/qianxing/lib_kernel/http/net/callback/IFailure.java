package taojinke.qianxing.lib_kernel.http.net.callback;


public interface IFailure {
    void onFailure();
}
