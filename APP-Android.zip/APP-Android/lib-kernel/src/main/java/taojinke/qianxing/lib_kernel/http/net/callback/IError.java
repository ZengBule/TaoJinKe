package taojinke.qianxing.lib_kernel.http.net.callback;


public interface IError {

    void onError(int code, String msg);
}
