package taojinke.qianxing.lib_kernel.http.net.callback;


public interface ISuccess {

    void onSuccess(String responce);
}
