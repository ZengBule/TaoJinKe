package taojinke.qianxing.lib_kernel.http.net.callback;


public interface IRequest {

    void onRequestStart();

    void onRequestEnd();
}
