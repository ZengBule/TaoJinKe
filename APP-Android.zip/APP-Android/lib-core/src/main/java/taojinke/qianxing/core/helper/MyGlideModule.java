package taojinke.qianxing.core.helper;

import com.bumptech.glide.annotation.GlideModule;
import com.bumptech.glide.module.AppGlideModule;

/**
 * 构建MyGlideModule
 * Created by cc on 2018/5/8.
 */

@GlideModule
public class MyGlideModule  extends AppGlideModule {

}
