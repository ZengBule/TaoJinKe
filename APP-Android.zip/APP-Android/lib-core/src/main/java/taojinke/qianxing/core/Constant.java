package taojinke.qianxing.core;

/**
 * ***********************************************
 * 包路径：taojinke.qianxing.core
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/3/1+16:02
 * 修改人：
 * 修改时间：2019/3/1+16:02
 * 修改备注：
 * ***********************************************
 */
public class Constant {

    public static final String WEB_TOKEN_KEY = "tjk_login_token";
}
