package taojinke.qianxing.chat.dagger.activity;


public interface ActivityComponentInjects {

}
