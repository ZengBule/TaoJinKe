package taojinke.qianxing.chat.dagger.fragment;

public interface FragmentComponentInjects {
}
