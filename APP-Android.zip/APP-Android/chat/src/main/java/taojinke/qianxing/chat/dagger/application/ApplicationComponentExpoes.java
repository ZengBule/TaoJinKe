package taojinke.qianxing.chat.dagger.application;


import taojinke.qianxing.chat.dagger.application.module.ApplicationLikeModule;

public interface ApplicationComponentExpoes extends ApplicationLikeModule.Exposes {
}
