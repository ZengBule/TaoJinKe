import android.app.Application;

public class ChatApplication extends Application {

    @Override
    public void onCreate() {
        super.onCreate();

    }
}
