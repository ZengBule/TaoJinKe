package taojinke.qianxing.mine.ui.mine;

import javax.inject.Inject;


/**
 * ***********************************************
 * 包路径：taojinke.qianxing.mine.ui.mine
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/2/21+14:52
 * 修改人：
 * 修改时间：2019/2/21+14:52
 * 修改备注：
 * ***********************************************
 */
public class MinePresenter implements MineContract.IMinePresenter {
    @Inject
    MineContract.IMineView mView;

    @Override
    public void approveRealName() {

    }
}
