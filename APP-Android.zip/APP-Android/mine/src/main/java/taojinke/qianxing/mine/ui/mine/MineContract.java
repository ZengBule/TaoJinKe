package taojinke.qianxing.mine.ui.mine;

import taojinke.qianxing.lib_base.base.BaseView;


/**
 * ***********************************************
 * 包路径：taojinke.qianxing.mine.ui.mine
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/2/21+14:52
 * 修改人：
 * 修改时间：2019/2/21+14:52
 * 修改备注：
 * ***********************************************
 */
public interface MineContract {
    interface IMineView extends BaseView {


    }

    interface IMinePresenter {
        void approveRealName();
    }
}
