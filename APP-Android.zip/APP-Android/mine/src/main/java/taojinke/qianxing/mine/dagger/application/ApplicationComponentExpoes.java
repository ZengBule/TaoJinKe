package taojinke.qianxing.mine.dagger.application;


import taojinke.qianxing.mine.dagger.application.module.ApplicationLikeModule;

public interface ApplicationComponentExpoes extends ApplicationLikeModule.Exposes {
}
