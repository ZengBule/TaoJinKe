package taojinke.qianxing.mine.dagger.activity;


public interface ActivityComponentInjects {

    void inject(taojinke.qianxing.mine.ui.main.MainPresenter presenter);

    void inject(taojinke.qianxing.mine.ui.main.MainActivity activity);
}
