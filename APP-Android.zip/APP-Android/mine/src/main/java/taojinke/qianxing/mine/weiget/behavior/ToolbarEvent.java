package taojinke.qianxing.mine.weiget.behavior;

/**
 * ***********************************************
 * 包路径：qianxing.taojinke.widget.behavior
 * 类描述：
 * 创建人：曾小浪[PHONE：18613223863]
 * 创建时间：2019/1/9+17:42
 * 修改人：
 * 修改时间：2019/1/9+17:42
 * 修改备注：
 * ***********************************************
 */
public class ToolbarEvent {
    public boolean isVisiti;
    public int intAlpha;
}
