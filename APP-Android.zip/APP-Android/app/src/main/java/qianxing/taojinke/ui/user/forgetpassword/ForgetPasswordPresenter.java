package qianxing.taojinke.ui.user.forgetpassword;

import javax.inject.Inject;

/**
 * ***********************************************
 * 包路径：qianxing.taojinke.ui.user.forgetpassword
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/2/18+15:19
 * 修改人：
 * 修改时间：2019/2/18+15:19
 * 修改备注：
 * ***********************************************
 */
public class ForgetPasswordPresenter implements ForgetPasswordContract.IForgetPasswordPresenter {
    @Inject
    ForgetPasswordContract.IForgetPasswordView mView;
}
