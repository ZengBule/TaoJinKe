package qianxing.taojinke.ui.user.forgetpassword;

import taojinke.qianxing.lib_base.base.BaseView;


/**
 * ***********************************************
 * 包路径：qianxing.taojinke.ui.user.forgetpassword
 * 类描述：
 *
 * @author：曾小浪[PHONE：18613223863] 创建时间：2019/2/18+15:19
 * 修改人：
 * 修改时间：2019/2/18+15:19
 * 修改备注：
 * ***********************************************
 */
public interface ForgetPasswordContract {
    interface IForgetPasswordView extends BaseView {

    }

    interface IForgetPasswordPresenter {

    }
}
