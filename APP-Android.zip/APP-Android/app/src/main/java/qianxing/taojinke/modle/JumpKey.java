package qianxing.taojinke.modle;

/**
 * Created by Administrator on 2017/8/30.
 */

public class JumpKey {
    //login and update password activity
    public static final String REGISTER_USER_KEY = "key_register_user";
    public static final String FORGET_PASSWORD_KEY = "key_forget_password";
    public static final String UPDATE_BIND_PHONE_KEY = "key_update_bind_phone";
    public static final String BIND_NEW_PHONE_KEY ="key_bind_new_phone";
    public static final String UPDATE_LOGIN_PASSWORD_KEY = "key_update_login_password";
    public static final String UPDATE_PAY_PASSWORD_KEY = "key_update_pay_password";
    public static final String SET_FORWARD_PASSWORD_KEY = "key_set_forward_password";
    public static final String MODIFY_FORWARD_PASSWORD_KEY = "key_modify_forward_password";
    public static final String RESET_LOGIN_PASSWORD_KEY = "key_reset_login_password";

    //setting
    public static final String SETTING_COMPLAIN_KEY = "key_setting_complain";
    public static final String SETTING_PRAISSE_KEY = "key_setting_praise";
    public static final String SETTING_ADVISE_KEY = "key_setting_advise";

}
