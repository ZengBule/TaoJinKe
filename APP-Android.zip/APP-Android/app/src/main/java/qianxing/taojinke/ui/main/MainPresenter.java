package qianxing.taojinke.ui.main;

import javax.inject.Inject;


public class MainPresenter implements MainContract.IMainPresenter {
    @Inject
    MainContract.IMainView mView;
}
