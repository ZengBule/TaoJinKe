package qianxing.taojinke.dagger.application;

import qianxing.taojinke.dagger.application.module.ApplicationLikeModule;

public interface ApplicationComponentExpoes extends ApplicationLikeModule.Exposes {
}
