package qianxing.taojinke.ui.main;


import taojinke.qianxing.lib_base.base.BaseView;

public interface MainContract {
    interface IMainView extends BaseView {

    }

    interface IMainPresenter  {

    }
}
