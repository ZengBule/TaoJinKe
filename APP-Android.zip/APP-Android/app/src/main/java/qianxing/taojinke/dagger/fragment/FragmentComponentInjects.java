package qianxing.taojinke.dagger.fragment;

public interface FragmentComponentInjects {
}
